var searchData=
[
  ['setcorners',['setCorners',['../class_target_finder.html#ad0128381587c692a207c1649f652a6d0',1,'TargetFinder']]],
  ['sethsv_5frange',['setHSV_Range',['../class_target_finder.html#acf8299d3697bf4609acde7b7c21f94f7',1,'TargetFinder']]],
  ['standarized_5fdeviation',['Standarized_Deviation',['../class_target_finder.html#ab73989a46c3a99b407f016c6ce881be3',1,'TargetFinder']]]
];
