var searchData=
[
  ['enable_5froi_5fselection',['enable_ROI_selection',['../class_open_cview.html#af8438083e3af2876e7e362b26b480752',1,'OpenCview']]]
];
